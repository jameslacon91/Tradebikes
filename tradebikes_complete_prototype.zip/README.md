
# TradeBikes Fullstack Prototype

Includes:
- Frontend: React + Tailwind (Vite)
- Backend: FastAPI + PostgreSQL + JWT

Deploy frontend on Vercel, backend on Render.
See .env.template files for required variables.
